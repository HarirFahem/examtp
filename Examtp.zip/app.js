const mongoose= require('mongoose')
const express = require('express')
const dotenv=require('dotenv');
const { questionRouter } = require('./routes/question');


dotenv.config(); 
//mongodb
mongoose.connect
(process.env.Database_url)
.then(()=>console.log("connected to mongodb atlas"))
.catch(err=>console.log(err))

//express
const app=express();

//middleware to parse json data on body request
app.use(express.json())

app.use(express.static("./public"))




app.use('/question',questionRouter)

const port =process.env.port || 3000
app.listen(port, ()=>{
    console.log('server listening on port : ',port)
})