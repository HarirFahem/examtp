const { default: mongoose } = require("mongoose");

const schema= new mongoose.Schema({
    Question:{
        type:String,
        required:true
    },
    Reponse:{
        type:Boolean,
        required:true
    }
})
const Question=mongoose.model("Question",schema)

module.exports={schemaQuestion:schema,Question:Question}