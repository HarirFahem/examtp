export const url ="http://localhost:3000";

export const Inputquest= document.getElementById("Inputquest")
export const selector= document.getElementById("selector")

export const resetbtn= document.getElementById("resetbtn")
export const submitbtn= document.getElementById("submitbtn")
export const divquestion=document.getElementById("questions")
