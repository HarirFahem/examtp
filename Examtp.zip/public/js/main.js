import { submitbtn,resetbtn,Inputquest, divquestion,selector } from "./config.js";
import { load ,addQuest } from "./question.js";


load();
submitbtn.addEventListener('click',()=>{
    const  Question =Inputquest.value
    const   Reponse = selector.value
    if(!Question || !Reponse)
        return alert("please provide a content for your memo")

    addQuest(Question,Reponse)
})


resetbtn.addEventListener('click',()=>{
    Inputquest.value=""
})

export const addQuestToTable=(content)=>{
    const {Question,Reponse,_id} = content

    // creation des elemments
    const div= document.createElement("div")
    const span= document.createElement("span")
    const divquest= document.createElement("div")
    const btndelete= document.createElement("button")
    const btnSwitch= document.createElement("button")
    span.setAttribute("id",_id)
    // liaison parent.appendChild(fils)
    div.appendChild(span)
    div.appendChild(divquest)
    div.appendChild(btndelete)
    div.appendChild(btnSwitch)
    


    //remplissage
    divquest.innerText=Question
    btndelete.innerText="delete"
    btnSwitch.innerText="switch"
    
    btndelete.classList.add("delete")
    btndelete.addEventListener("click",()=>{
       
        //delete
    })
    btnSwitch.classList.add("delete")
    btnSwitch.addEventListener("click",()=>{
        //switch
       
    })

    divquestion.appendChild(div)
}
