import { addQuestToTable } from "./main.js";
import { url } from "./config.js";

export const load=()=>{
    fetch(url+"/question",{
        method:"GET",
        headers:{
            'Content-Type': 'application/json'
        }
    }).then(res=>res.json()).then(data=>{
        //console.log(data)
        //data => array
        data.forEach(element => {
            addQuestToTable(element)
        });

    })
    .catch(err=>{
        alert("error");
        console.log(err)
    }).finally(()=>{
     
    })
}

export const addQuest=(content)=>{
    const dataToSend = {
        question:question,
        Reponse:Reponse
    }
    fetch(url+"/question",{
        method:"POST",
        body:JSON.stringify(dataToSend),
        headers:{
            'Content-Type': 'application/json'
        }
    }).then(res=>{
        if(res.ok)
        {
            res.json().then(data=>{
                addMemoToTable(data)
            })
        }
        else{
            alert("erreur")
        }
    })
    .catch(err=>{
        alert("erreur")
        console.log(err)
    })
}