const express= require('express')
const {Question} = require("../models/Questions")
const router = express.Router();



router.post("",async (req,res)=>{

    // recuperation des donnees envoyees
   const {quest, Select } =  req.body
   // verification
   if(!quest || !Select)
    return res.status(400).json({message:"date and content are required"})


  // creer une instance du model
    const question= new Question({
        Question:quest,
        Reponse:Select
    })
  
    

    question.save().then(()=>res.status(200).json(question)).catch(err=>res.status(400).json(err))

})

router.get("",async (req,res)=>{
     const nbr=req.query.nbr
        const allQuest = await Question.find();
        return res.status(200).json(allQuest);
      });
      
 

router.put('/:idquest',async (req,res)=>{
    const idquest=req.params.idquest
    //const {Reponse}=req.body;
    const Quest = await Question.findById(idquest).select('Reponse')
    //Quest.Reponse= Select
    console.log(Quest.Reponse)
    if(Quest.Reponse){
        //
        Quest.Reponse=false
    } else{

        Quest.Reponse=true
    }

    Quest.save().then(()=>{
    res.json({msg:'updated successfuly'})
   }).catch(err=>res.status(500).json({err:err.message}))
})

router.delete("/:idquest",async (req,res)=>{
    
    const idquest = req.params.idquest

   Question.findByIdAndDelete(idquest).then(()=>{
    res.json({msg:'removed successfuly'})
   }).catch(err=>res.status(500).json({err:err.message}))

})

module.exports.questionRouter= router;
